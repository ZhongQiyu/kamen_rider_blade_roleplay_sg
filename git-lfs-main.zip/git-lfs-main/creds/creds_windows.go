//go:build windows
// +build windows

package creds

var netrcBasename = "_netrc"
